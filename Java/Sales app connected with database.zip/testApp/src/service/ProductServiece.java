
package service;

import entity.Product;
import java.sql.Connection;
import java.sql.PreparedStatement;
import testapp.connection.DbConnection;

public class ProductServiece {
    
    public void saveNewSales(Product product){
        DbConnection con = new DbConnection();
        Connection connection = con.connect();
        
        try{
            String query = " insert into product (prodactID, ProductName, Price)"
            + " values (?, ?, ?)";
            // create the mysql insert preparedstatement
            PreparedStatement preparedStmt = connection.prepareStatement(query);
            preparedStmt.setInt (1, product.getProductid());
            preparedStmt.setString(2, product.getProductName());
            preparedStmt.setInt(3, product.getProductprice());
            // execute the preparedstatement
            preparedStmt.execute();


        }catch(Exception ex){
           System.out.println("Error: "+ex); 
        }
    }    
    
}
